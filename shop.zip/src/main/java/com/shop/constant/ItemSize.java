package com.shop.constant;

public enum ItemSize {
    XXL , XL , L , M , S;
}
