package com.shop.constant;

public enum ItemType {
    TOP,PANTS, OUTER, ETC
}
