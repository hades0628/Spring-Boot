package com.shop.dto;

public class WishDto {
}
